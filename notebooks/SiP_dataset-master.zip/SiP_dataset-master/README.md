The SiP dataset

The data is described in the paper:
"A conversation around the analysis of the SiP effort estimation dataset" by Derek M. Jones and Stephen Cullum

https://arxiv.org/pdf/1901.01621.pdf

If you make use of this data in a paper, please let us know.

[Fullstack D3 and Data Visualization](https://wattenberger.com/blog/d3-interactive-charts) by Amelia Wattenberger, uses the SiP dataset in example plots.

