The R code used in the analsysis of the SiP dataset.

ukbankholidays.csv is a list of UK public holidays (needed by the bizdays package).

